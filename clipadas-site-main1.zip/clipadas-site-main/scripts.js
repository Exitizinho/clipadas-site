// reservado para:
// - carousel auto
// - cliques
// - vídeos reais
// - shorts feed
